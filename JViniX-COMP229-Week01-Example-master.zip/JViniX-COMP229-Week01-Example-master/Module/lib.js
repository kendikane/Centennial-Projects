export function halfOf(x) {
    return x / 2;
}

export function multiply(x, y) {
    return x * y;
}

export default function () {
    console.log('I did something')
};
