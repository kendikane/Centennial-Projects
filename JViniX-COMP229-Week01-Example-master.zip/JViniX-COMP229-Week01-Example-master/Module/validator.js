export var flag = false;

export function touch() {
   flag = true;
}